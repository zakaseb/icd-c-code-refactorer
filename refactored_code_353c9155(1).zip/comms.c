#include "comms.h"
#include <string.h>

static uint8_t g_system_id = 0;
static uint16_t g_seq_counter = 0;

int Comms_Init(uint8_t system_id)
{
    g_system_id = system_id;
    g_seq_counter = 0;
    return 0;
}

uint16_t Comms_CRC16(const uint8_t* data, size_t length)
{
    uint16_t crc = 0xFFFF;
    const uint8_t* ptr = data;
    size_t i;

    for (i = 0; i < length; i++) {
        crc ^= *ptr++ << 8;
        for (uint8_t j = 0; j < 8; j++) {
            if (crc & 0x8000) {
                crc = (crc << 1) ^ 0x1021;
            } else {
                crc <<= 1;
            }
        }
    }
    return crc;
}

int Comms_Send(uint8_t msg_id, uint16_t seq_num, uint8_t priority, const uint8_t* payload, uint16_t payload_len)
{
    if (!payload || payload_len > MAX_PAYLOAD_LEN) {
        return -1;
    }
    
    CommMessage msg;
    memset(&msg, 0, sizeof(msg));
    msg.msg_id = msg_id;
    msg.seq_num = seq_num;
    msg.priority = priority;
    msg.payload_len = payload_len;
    memcpy(msg.payload, payload, payload_len);
    msg.crc16 = Comms_CRC16((const uint8_t*)&msg.msg_id, sizeof(msg.msg_id) + 
                           sizeof(msg.seq_num) + 
                           sizeof(msg.priority) + 
                           sizeof(msg.payload_len) + 
                           payload_len);

    /* In real code this would write to a hardware bus */
    return 0;
}

int Comms_Receive(uint8_t* msg_id, uint16_t* seq_num, uint8_t* priority, uint8_t* payload, uint16_t* payload_len)
{
    if (!msg_id || !seq_num || !priority || !payload || !payload_len) {
        return -1;
    }
    
    /* In real code this would read from a hardware bus */
    *msg_id = 0;
    *seq_num = 0;
    *priority = 0;
    *payload_len = 0;
    return 0;
}

int Comms_SendStatus(uint8_t system_id, state_t state, uint32_t uptime_sec, int16_t temperature, uint16_t voltage_mv, uint16_t error_count)
{
    StatusReport report;
    report.system_id = system_id;
    report.state = state;
    report.uptime_sec = uptime_sec;
    report.temperature = temperature;
    report.voltage_mv = voltage_mv;
    report.error_count = error_count;

    CommMessage msg;
    memset(&msg, 0, sizeof(msg));
    msg.msg_id = MSG_ID_STATUS;
    msg.seq_num = g_seq_counter++;
    msg.priority = 1; // normal priority
    msg.payload_len = sizeof(StatusReport);
    memcpy(msg.payload, &report, sizeof(StatusReport));
    msg.crc16 = Comms_CRC16((const uint8_t*)&msg.msg_id, sizeof(msg.msg_id) + 
                           sizeof(msg.seq_num) + 
                           sizeof(msg.priority) + 
                           sizeof(msg.payload_len) + 
                           msg.payload_len);

    return Comms_Send(msg.msg_id, msg.seq_num, msg.priority, msg.payload, msg.payload_len);
}

int Comms_SendAck(uint8_t msg_id, uint16_t seq_num)
{
    // ACK payload contains original message ID and sequence number
    uint8_t ack_payload[2];
    ack_payload[0] = msg_id;
    ack_payload[1] = (uint8_t)(seq_num & 0xFF);
    
    return Comms_Send(MSG_ID_ACK, seq_num, 2, ack_payload, sizeof(ack_payload));
}

int Comms_SendDiagnostic(const uint8_t* payload, uint16_t payload_len)
{
    return Comms_Send(MSG_ID_DIAGNOSTIC, g_seq_counter++, 3, payload, payload_len);
}