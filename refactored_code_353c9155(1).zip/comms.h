#ifndef COMMS_H
#define COMMS_H

#include <stdint.h>
#include <stddef.h>

/* ICD v2.0 message definitions */

#define MSG_ID_HEARTBEAT   0x01
#define MSG_ID_STATUS      0x02
#define MSG_ID_COMMAND     0x03
#define MSG_ID_ACK         0x04
#define MSG_ID_DIAGNOSTIC  0x05

#define MAX_PAYLOAD_LEN    128

typedef enum {
    STATE_IDLE          = 0,
    STATE_ACTIVE        = 1,
    STATE_ERROR         = 2,
    STATE_MAINTENANCE   = 3
} SystemState;

typedef struct {
    uint8_t  msg_id;
    uint16_t seq_num;
    uint8_t  priority;
    uint16_t payload_len;
    uint8_t  payload[MAX_PAYLOAD_LEN];
    uint16_t crc16;
} CommMessage;

typedef struct {
    uint8_t     system_id;
    SystemState state;
    uint32_t    uptime_sec;
    int16_t     temperature;
    uint16_t    voltage_mv;
    uint16_t    error_count;
} StatusReport;

/* Initialize the communication subsystem */
int  Comms_Init(uint8_t system_id);

/* Send a message over the bus */
int  Comms_Send(uint8_t msg_id, uint16_t seq_num, uint8_t priority, const uint8_t* payload, uint16_t payload_len);

/* Receive a message (blocking, timeout in ms) */
int  Comms_Receive(uint8_t* msg_id, uint16_t* seq_num, uint8_t* priority, uint8_t* payload, uint16_t* payload_len);

/* Build and send a status report */
int  Comms_SendStatus(const StatusReport *report);

/* Compute CRC16 for message data */
uint16_t Comms_CRC16(const uint8_t* data, size_t length);

/* Send an acknowledgment message */
int  Comms_SendAck(uint8_t msg_id, uint16_t seq_num);

/* Send a diagnostic message */
int  Comms_SendDiagnostic(const uint8_t* payload, uint16_t payload_len);

#endif /* COMMS_H */